import { Hotel } from './hotel.js';
import { Hotelkette } from './hotelkette.js';

const meineHotelkette = new Hotelkette('FiveStar');

meineHotelkette.hotelHinzufuegen(new Hotel('Quay', 45, 12));
meineHotelkette.hotelHinzufuegen(new Hotel('Park', 77, 14));

meineHotelkette.zeigeAlleHotels();