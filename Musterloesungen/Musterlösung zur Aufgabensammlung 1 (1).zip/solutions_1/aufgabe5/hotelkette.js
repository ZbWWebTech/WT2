import { Hotel } from './hotel.js';

class Hotelkette {
    constructor(nameDerHotelkette) {
        this.name = nameDerHotelkette;
        this.hotels = [];
    }

    hotelHinzufuegen(hotel) {
        if (hotel instanceof Hotel)
            this.hotels.push(hotel);
        else
            throw new TypeError("Ist kein Hotel-Objekt"); // eine Exception wird ausgelöst
    }

    zeigeAlleHotels() {
        if (this.hotels.length > 0) {
            this.hotels.forEach(hotel => {
                console.log(hotel.gibInformationen());
                console.log('--------------------------------------------');
            });
        }
    }
}

export { Hotelkette };