class Hotel {
    constructor(name, anzahlZimmer, gebuchteZimmer) {
        this.name = name;
        this.zimmer = anzahlZimmer;
        this.gebucht = gebuchteZimmer;
    }

    gibFreieZimmer() {
        return this.zimmer - this.gebucht;
    };

    gibInformationen() {
        return 'Name des Hotels: ' + this.name +
            ', Anzahl Zimmer: ' + this.zimmer +
            ', Gebuchte Zimmer: ' + this.gebucht +
            ', Freie Zimmer: ' + this.gibFreieZimmer();
    };
}

class Hotelkette {
    constructor(nameDerHotelkette) {
        this.name = nameDerHotelkette;
        this.hotels = [];
    }

    hotelHinzufuegen(hotel) {
        if (hotel instanceof Hotel)
            this.hotels.push(hotel);
        else
            throw new TypeError("Ist kein Hotel-Objekt"); // eine Exception wird ausgelöst
    }

    zeigeAlleHotels() {
        if (this.hotels.length > 0) {
            this.hotels.forEach(hotel => {
                console.log(hotel.gibInformationen());
                console.log('--------------------------------------------');
            });
        }
    }
}

const meineHotelkette = new Hotelkette('FiveStar');

meineHotelkette.hotelHinzufuegen(new Hotel('Quay', 45, 12));
meineHotelkette.hotelHinzufuegen(new Hotel('Park', 77, 14));

meineHotelkette.zeigeAlleHotels();