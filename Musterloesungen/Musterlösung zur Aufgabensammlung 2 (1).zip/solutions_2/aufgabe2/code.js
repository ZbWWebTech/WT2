let maxwidth = window.screen.width;
let maxheight = window.screen.height;

console.log('Maximale Breite: ' + maxwidth + ' Pixel, maximale Höhe: ' + maxheight + ' Pixel');

let availwidth = window.screen.availWidth;
let availheight = window.screen.availHeight;

console.log('Verfügbare Breite: ' + availwidth + ' Pixel, Verfügbare Höhe: ' + availheight + ' Pixel');

let pixdepth = window.screen.pixelDepth;
let coldepth = window.screen.colorDepth;

console.log('Pixeldichte: ' + pixdepth + ' Bit, Farbtiefe: ' + coldepth + ' Bits per Pixel, ergibt ' + Math.pow(2, coldepth) + ' mögliche Farben.');