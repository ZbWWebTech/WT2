const locactionObject = {
    data: [
        ['host', window.location.hostname],
        ['port', window.location.port],
        ['prot', window.location.protocol],
        ['path', window.location.pathname]
    ],

    getLocationData() {
        this.data.forEach(element => {
            console.log(element.join(' : '));
        });
    }
}

locactionObject.getLocationData();