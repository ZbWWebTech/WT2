const clock = () => {
    const htmlElement = document.getElementById('time');

    const timeFormat = (value) => value < 10 ? '0' + value : value;

    const timer = setInterval(() => {
        const date = new Date();
        htmlElement.innerHTML = `${timeFormat(date.getHours())}:${timeFormat(date.getMinutes())}:${timeFormat(date.getSeconds())}`
    }, 1000)
};

clock();