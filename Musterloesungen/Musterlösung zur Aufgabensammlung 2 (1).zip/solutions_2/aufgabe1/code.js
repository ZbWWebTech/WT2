let ow = window.outerWidth;
let iw = window.innerWidth;

console.log('outer width=' + ow + ' Pixel,' + 'inner width=' + iw + ' Pixel');

let oh = window.outerHeight;
let ih = window.innerHeight;

console.log('outer height=' + oh + ' Pixel,' + 'inner height=' + ih + ' Pixel');